/**
 * gene PWA Google Sheets Backend
 * Googleスプレッドシート → 拡張機能 → Apps Script に貼り付けて使います。
 */
const API_KEY = 'CHANGE_ME_gene_private_key';
const SHEET_NAME = 'gene_app_state';
// LINE Messaging APIを使う場合に設定
const LINE_CHANNEL_ACCESS_TOKEN = '';
const LINE_TO_ID = '';

function doGet(e) {
  return jsonOutput({ ok: true, app: 'gene', message: 'Backend is running.' });
}
function doPost(e) {
  try {
    const body = JSON.parse(e.postData.contents || '{}');
    if (body.apiKey !== API_KEY) return jsonOutput({ ok: false, error: 'Invalid API key.' });
    if (body.action === 'sync') {
      const incoming = body.state;
      const saved = loadState_();
      if (!saved || !saved.updatedAt || new Date(incoming.updatedAt) >= new Date(saved.updatedAt)) {
        saveState_(incoming);
        return jsonOutput({ ok: true, state: incoming });
      }
      return jsonOutput({ ok: true, state: saved });
    }
    if (body.action === 'load') return jsonOutput({ ok: true, state: loadState_() });

    if (body.action === 'linePush') {
      return sendLinePush_(body.title || 'gene通知', body.message || '');
    }
    if (body.action === 'save') { saveState_(body.state); return jsonOutput({ ok: true, state: body.state }); }
    return jsonOutput({ ok: false, error: 'Unknown action.' });
  } catch (err) {
    return jsonOutput({ ok: false, error: String(err) });
  }
}
function loadState_() {
  const sheet = getSheet_();
  const value = sheet.getRange('A2').getValue();
  if (!value) return null;
  return JSON.parse(value);
}
function saveState_(state) {
  const sheet = getSheet_();
  sheet.getRange('A1').setValue('gene_app_state_json');
  sheet.getRange('A2').setValue(JSON.stringify(state));
  sheet.getRange('B1').setValue('updatedAt');
  sheet.getRange('B2').setValue(state.updatedAt || new Date().toISOString());
}
function getSheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_NAME);
  if (!sheet) sheet = ss.insertSheet(SHEET_NAME);
  return sheet;
}
function jsonOutput(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}


function sendLinePush_(title, message) {
  if (!LINE_CHANNEL_ACCESS_TOKEN || !LINE_TO_ID) {
    return jsonOutput({ ok: false, error: 'LINE token or to ID is not configured.' });
  }

  const url = 'https://api.line.me/v2/bot/message/push';
  const payload = {
    to: LINE_TO_ID,
    messages: [{
      type: 'text',
      text: title + '\n' + message
    }]
  };

  const res = UrlFetchApp.fetch(url, {
    method: 'post',
    contentType: 'application/json',
    headers: {
      Authorization: 'Bearer ' + LINE_CHANNEL_ACCESS_TOKEN
    },
    payload: JSON.stringify(payload),
    muteHttpExceptions: true
  });

  const code = res.getResponseCode();
  if (code >= 200 && code < 300) {
    return jsonOutput({ ok: true });
  }

  return jsonOutput({ ok: false, error: res.getContentText() });
}
